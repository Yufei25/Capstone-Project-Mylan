pip install --upgrade pip
pip install django==1.10
# virtualenv -p python venv
# source venv/bin/activate
# pip freeze > requirements.txt
# pip install -r requirements.txt

python manage.py runserver
open -a "/Applications/Safari.app" http://127.0.0.1